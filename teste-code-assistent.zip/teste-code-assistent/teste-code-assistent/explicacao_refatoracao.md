# Explicação do Código - refatoracao.py

## Linha 1-2: Definição da Função `summarize_numbers`
```python
def summarize_numbers(numbers):
    """Return the sum, average, maximum, and minimum of a list of numbers."""
```
- **Linha 1**: Define uma função chamada `summarize_numbers` que recebe um parâmetro `numbers` (uma lista de números)
- **Linha 2**: A string entre aspas triplas é a **docstring** (documentação) da função. Descreve o que a função faz

## Linha 3-6: Cálculos Dentro da Função
```python
    total = sum(numbers)
    average = total / len(numbers)
    maximum = max(numbers)
    minimum = min(numbers)
```
- **Linha 3**: Calcula a **soma** de todos os números da lista usando `sum()` e armazena na variável `total`
- **Linha 4**: Calcula a **média** dividindo o total pela quantidade de elementos (obtida com `len()`)
- **Linha 5**: Encontra o **número maior** da lista usando `max()` e armazena em `maximum`
- **Linha 6**: Encontra o **número menor** da lista usando `min()` e armazena em `minimum`

## Linha 7: Retorno da Função
```python
    return total, average, maximum, minimum
```
- Retorna os 4 valores calculados como uma **tupla** (múltiplos valores separados por vírgula)

## Linha 10-11: Definição da Função `main`
```python
def main():
    sample_values = [23, 7, 45, 2, 67, 12, 89, 34, 56, 11]
```
- **Linha 10**: Define a função `main()` que será o ponto de entrada do programa
- **Linha 11**: Cria uma lista chamada `sample_values` com 10 números para teste

## Linha 12: Chamada da Função
```python
    total, average, maximum, minimum = summarize_numbers(sample_values)
```
- Chama a função `summarize_numbers()` passando a lista `sample_values` como argumento
- **Desempacotamento**: Os 4 valores retornados pela função são atribuídos às variáveis `total`, `average`, `maximum` e `minimum`

## Linha 14-17: Exibição dos Resultados
```python
    print("total:", total)
    print("media:", average)
    print("maior:", maximum)
    print("menor:", minimum)
```
- **Linha 14**: Exibe a soma dos números
- **Linha 15**: Exibe a média dos números (com rótulo "media" em português)
- **Linha 16**: Exibe o maior número (com rótulo "maior" em português)
- **Linha 17**: Exibe o menor número (com rótulo "menor" em português)

## Linha 20-21: Bloco de Execução Principal
```python
if __name__ == "__main__":
    main()
```
- **Linha 20**: Verifica se o script está sendo executado diretamente (não sendo importado como módulo)
- **Linha 21**: Se verdadeiro, chama a função `main()` para iniciar o programa

---

## Resumo do Fluxo
1. O usuário executa o script
2. O bloco `if __name__ == "__main__"` é ativado
3. A função `main()` é chamada
4. `main()` cria uma lista de números
5. Chama `summarize_numbers()` para calcular estatísticas
6. Os resultados são exibidos no console
