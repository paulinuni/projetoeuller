# Verificador de Números Primos

Este projeto contém uma função em Python que verifica se um número é primo.

## Função `is_prime(n)`

A função `is_prime(n)` recebe um número inteiro `n` e retorna `True` se o número for primo, ou `False` caso contrário.

### Como funciona:

1. **Casos base:**
   - Se `n` for menor ou igual a 1, retorna `False` (números não positivos não são primos).
   - Se `n` for 2, retorna `True` (2 é o único número primo par).
   - Se `n` for par e maior que 2, retorna `False` (não é primo).

2. **Verificação de divisores:**
   - Para números ímpares maiores que 2, verifica se há divisores ímpares de 3 até a raiz quadrada de `n`.
   - Se encontrar algum divisor, retorna `False`.
   - Se não encontrar nenhum divisor, retorna `True`.

### Eficiência:
- A função é eficiente porque verifica apenas até a raiz quadrada de `n`, reduzindo o número de operações.
- Ignora números pares maiores que 2, otimizando ainda mais.

## Testes

O código inclui testes com os seguintes números: 1, 2, 3, 4, 5, 17, 18, 19, 23.

Para executar o código e ver os resultados dos testes, rode:

```bash
python num_primo.py
```

## Exemplo de uso:

```python
from num_primo import is_prime

print(is_prime(7))  # True
print(is_prime(10)) # False
```