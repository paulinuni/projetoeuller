def is_prime(n):
    """
    Verifica se um número é primo.
    
    Args:
        n (int): O número a ser verificado.
    
    Returns:
        bool: True se o número for primo, False caso contrário.
    """
    if n <= 1:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True

# Testes
if __name__ == "__main__":
    test_cases = [1, 2, 3, 4, 5, 17, 18, 19, 23]
    for num in test_cases:
        print(f"{num} é primo? {is_prime(num)}")